class BankAccount:
    def __init__(self, intrest_rate, balance, name):
        self.intrest_rate = intrest_rate
        self.balance = balance
        self.name = name
    def withdrawl(self, balance):
        self.balance -= balance
    def display_balance(self, balance, name):
        print(f"Account_Name:{self.name}, Balance:{self.balance}")


damon = self.name("Damon")

damon.withdrawl(10)
damon.display_balance()
